package FunctieGrafic;

public class MainApp {
    public static void main(String[] args) {
        Parabola parabola = new Parabola(4,-2,1);

        System.out.println(parabola);
    }
}
