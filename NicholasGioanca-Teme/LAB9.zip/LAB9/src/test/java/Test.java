public class Test package lab9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemaLabJpaSpringDataJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
o{
}
