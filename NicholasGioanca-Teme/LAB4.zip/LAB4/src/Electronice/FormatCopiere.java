package Electronice;

public enum FormatCopiere{
    A3,
    A4
}
