package Electronice;

public enum SistemOperare{
    Windows,
    Linux
}
