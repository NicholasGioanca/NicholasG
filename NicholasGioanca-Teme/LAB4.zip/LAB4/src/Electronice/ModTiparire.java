package Electronice;

public enum ModTiparire{
    COLOR,
    ALB_NEGRU
}
