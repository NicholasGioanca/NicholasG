package Electronice;

public enum StareEchipament{
    ACHIZITIONAT,
    EXPUS,
    VANDUT
}
