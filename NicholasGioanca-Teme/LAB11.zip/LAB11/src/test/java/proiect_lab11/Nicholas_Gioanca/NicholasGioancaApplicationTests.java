package proiect_lab11.Nicholas_Gioanca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NicholasGioancaApplicationTests {

	@Test
	void contextLoads() {
	}

}
